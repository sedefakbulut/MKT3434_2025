import sys
import numpy as np
import pandas as pd
import plotly.express as px
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QTabWidget, QPushButton, QLabel, 
                             QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                             QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                             QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                             QDialog, QLineEdit)
from PyQt6.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection, decomposition, discriminant_analysis, metrics, cluster
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
import umap

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI - 21067040")
        self.setGeometry(100, 100, 1400, 800)
        
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()

    def create_data_section(self):
        data_group = QGroupBox("Data Management")
        data_layout = QHBoxLayout()
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems(["Iris", "Digits", "Breast Cancer"])
        self.load_btn = QPushButton("Load Dataset")
        self.load_btn.clicked.connect(self.load_dataset)
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        data_layout.addWidget(QLabel("Dataset:"))
        data_layout.addWidget(self.dataset_combo)
        data_layout.addWidget(self.load_btn)
        data_layout.addWidget(QLabel("Test Split:"))
        data_layout.addWidget(self.split_spin)
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

    def load_dataset(self):
        name = self.dataset_combo.currentText()
        if name == "Iris":
            data = datasets.load_iris()
        elif name == "Digits":
            data = datasets.load_digits()
        else:
            data = datasets.load_breast_cancer()
        X, y = data.data, data.target
        test_size = self.split_spin.value()
        self.X_train, self.X_test, self.y_train, self.y_test = model_selection.train_test_split(X, y, test_size=test_size, stratify=y, random_state=42)

    def create_tabs(self):
        self.tab_widget = QTabWidget()
        self.tab_widget.addTab(self.create_classical_ml_tab(), "Classical ML")
        self.tab_widget.addTab(self.create_dim_red_tab(), "Dimensionality Reduction")
        self.layout.addWidget(self.tab_widget)

    def create_classical_ml_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        self.model_combo = QComboBox()
        self.model_combo.addItems(["Logistic Regression", "KNN", "Random Forest"])
        layout.addWidget(QLabel("Select Model:"))
        layout.addWidget(self.model_combo)

        self.k_spin = QSpinBox()
        self.k_spin.setRange(2, 10)
        self.k_spin.setValue(5)
        layout.addWidget(QLabel("K-Fold:"))
        layout.addWidget(self.k_spin)

        train_btn = QPushButton("Run Cross-Validation")
        train_btn.clicked.connect(self.run_cross_validation)
        layout.addWidget(train_btn)

        return widget

    def run_cross_validation(self):
        model_name = self.model_combo.currentText()
        k = self.k_spin.value()

        if model_name == "Logistic Regression":
            model = LogisticRegression(max_iter=500)
        elif model_name == "KNN":
            model = KNeighborsClassifier()
        else:
            model = RandomForestClassifier()

        skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=42)

        accs, mses, rmses = [], [], []

        for train_idx, test_idx in skf.split(self.X_train, self.y_train):
            X_tr, X_te = self.X_train[train_idx], self.X_train[test_idx]
            y_tr, y_te = self.y_train[train_idx], self.y_train[test_idx]

            model.fit(X_tr, y_tr)
            y_pred = model.predict(X_te)

            acc = metrics.accuracy_score(y_te, y_pred)
            mse = metrics.mean_squared_error(y_te, y_pred)
            rmse = np.sqrt(mse)

            accs.append(acc)
            mses.append(mse)
            rmses.append(rmse)

        msg = f"""Cross-Validation Results ({k}-fold):
Accuracy: {np.mean(accs):.4f} ± {np.std(accs):.4f}
MSE: {np.mean(mses):.4f} ± {np.std(mses):.4f}
RMSE: {np.mean(rmses):.4f} ± {np.std(rmses):.4f}
"""
        self.metrics_text.setText(msg)

    def create_dim_red_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.pca_btn = QPushButton("Apply PCA")
        self.pca_btn.clicked.connect(self.apply_pca)
        self.lda_btn = QPushButton("Apply LDA")
        self.lda_btn.clicked.connect(self.apply_lda)
        self.umap_btn = QPushButton("Apply UMAP")
        self.umap_btn.clicked.connect(self.apply_umap)
        self.kmeans_btn = QPushButton("KMeans & Elbow Method")
        self.kmeans_btn.clicked.connect(self.apply_kmeans)
        layout.addWidget(self.pca_btn)
        layout.addWidget(self.lda_btn)
        layout.addWidget(self.umap_btn)
        layout.addWidget(self.kmeans_btn)
        return widget

    def create_visualization(self):
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)
        self.metrics_text = QTextEdit()
        self.layout.addWidget(self.metrics_text)

    def create_status_bar(self):
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

    def apply_pca(self):
        pca = decomposition.PCA(n_components=2)
        X_pca = pca.fit_transform(self.X_train)
        fig = px.scatter(x=X_pca[:,0], y=X_pca[:,1], color=self.y_train.astype(str), title="PCA Result")
        fig.show()

    def apply_lda(self):
        lda = discriminant_analysis.LinearDiscriminantAnalysis(n_components=2)
        X_lda = lda.fit_transform(self.X_train, self.y_train)
        fig = px.scatter(x=X_lda[:,0], y=X_lda[:,1], color=self.y_train.astype(str), title="LDA Result")
        fig.show()

    def apply_umap(self):
        reducer = umap.UMAP(n_components=2)
        X_umap = reducer.fit_transform(self.X_train)
        fig = px.scatter(x=X_umap[:,0], y=X_umap[:,1], color=self.y_train.astype(str), title="UMAP Result")
        fig.show()

    def apply_kmeans(self):
        distortions = []
        K = range(1, 10)
        for k in K:
            kmeans = cluster.KMeans(n_clusters=k)
            kmeans.fit(self.X_train)
            distortions.append(kmeans.inertia_)
        fig = px.line(x=list(K), y=distortions, title="Elbow Method")
        fig.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())
