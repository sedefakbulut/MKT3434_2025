
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, regularizers, callbacks
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QLabel, QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit,
    QListWidget, QFileDialog, QTextEdit, QProgressBar, QGroupBox, QCheckBox, QMessageBox, QDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import matplotlib.pyplot as plt

# ----------- Layer Item -------------
class LayerItem:
    def __init__(self, layer_type, params):
        self.layer_type = layer_type
        self.params = params
    def __str__(self):
        return f"{self.layer_type} - {self.params}"

# ----------- Training Thread -------------
class TrainThread(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    finished_signal = pyqtSignal(dict)
    def __init__(self, model, x_train, y_train, x_val, y_val, batch_size, epochs, callbacks_):
        super().__init__()
        self.model = model
        self.x_train = x_train
        self.y_train = y_train
        self.x_val = x_val
        self.y_val = y_val
        self.batch_size = batch_size
        self.epochs = epochs
        self.callbacks_ = callbacks_
    def run(self):
        logs = []
        class CustomLogger(callbacks.Callback):
            def on_epoch_end(inner_self, epoch, logs_):
                log = f"Epoch {epoch+1}: " + ", ".join([f"{k}: {v:.4f}" for k, v in logs_.items()])
                logs.append(log)
                self.log_signal.emit(log)
                prog = int((epoch+1)/self.epochs*100)
                self.progress_signal.emit(prog)
        hist = self.model.fit(
            self.x_train, self.y_train,
            epochs=self.epochs,
            batch_size=self.batch_size,
            validation_data=(self.x_val, self.y_val),
            callbacks=[CustomLogger()] + self.callbacks_,
            verbose=0
        )
        self.finished_signal.emit(hist.history)

# ----------- GAN Thread -------------
class GANThread(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    finished_signal = pyqtSignal(object)
    def __init__(self, x_train, epochs=10, batch_size=128, latent_dim=32):
        super().__init__()
        self.x_train = x_train.reshape(-1, 28*28)
        self.epochs = epochs
        self.batch_size = batch_size
        self.latent_dim = latent_dim
        self.generator = tf.keras.Sequential([
            layers.Input(shape=(latent_dim,)),
            layers.Dense(256, activation="relu"),
            layers.Dense(512, activation="relu"),
            layers.Dense(784, activation="tanh"),
        ])
        self.discriminator = tf.keras.Sequential([
            layers.Input(shape=(784,)),
            layers.Dense(512, activation="relu"),
            layers.Dense(256, activation="relu"),
            layers.Dense(1, activation="sigmoid"),
        ])
        self.cross_entropy = tf.keras.losses.BinaryCrossentropy()
        self.gen_opt = tf.keras.optimizers.Adam(1e-4)
        self.disc_opt = tf.keras.optimizers.Adam(1e-4)
    def run(self):
        x_train = self.x_train * 2 - 1
        for epoch in range(self.epochs):
            for i in range(0, x_train.shape[0], self.batch_size):
                real_imgs = x_train[i:i+self.batch_size]
                noise = np.random.randn(real_imgs.shape[0], self.latent_dim)
                fake_imgs = self.generator.predict(noise, verbose=0)
                # Discriminator
                with tf.GradientTape() as tape:
                    real_out = self.discriminator(real_imgs)
                    fake_out = self.discriminator(fake_imgs)
                    d_loss = self.cross_entropy(tf.ones_like(real_out), real_out) + \
                             self.cross_entropy(tf.zeros_like(fake_out), fake_out)
                grads = tape.gradient(d_loss, self.discriminator.trainable_variables)
                self.disc_opt.apply_gradients(zip(grads, self.discriminator.trainable_variables))
                # Generator
                noise = np.random.randn(real_imgs.shape[0], self.latent_dim)
                with tf.GradientTape() as tape:
                    fake_imgs = self.generator(noise)
                    fake_out = self.discriminator(fake_imgs)
                    g_loss = self.cross_entropy(tf.ones_like(fake_out), fake_out)
                grads = tape.gradient(g_loss, self.generator.trainable_variables)
                self.gen_opt.apply_gradients(zip(grads, self.generator.trainable_variables))
            self.log_signal.emit(f"Epoch {epoch+1}/{self.epochs}  D_loss={d_loss:.3f}  G_loss={g_loss:.3f}")
            self.progress_signal.emit(int((epoch+1)/self.epochs*100))
        self.finished_signal.emit(self.generator)

# ----------- Main Window -------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Deep Learning Designer")
        self.setGeometry(100, 100, 1200, 800)
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.layer_list = QListWidget()
        self.layer_items = []
        self.train_log = QTextEdit()
        self.train_log.setReadOnly(True)
        self.current_model = None
        self.training_history = None
        (self.x_train, self.y_train), (self.x_test, self.y_test) = tf.keras.datasets.mnist.load_data()
        self.x_train = self.x_train.astype("float32")/255.0
        self.x_test = self.x_test.astype("float32")/255.0
        self.x_train = np.expand_dims(self.x_train, -1)
        self.x_test = np.expand_dims(self.x_test, -1)
        self.init_model_tab()
        self.init_train_tab()
        self.init_result_tab()
        self.init_gan_tab()
        self.init_transfer_tab()
    # ------ Model Tab ------
    def init_model_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layer_box = QGroupBox("Layer List")
        vbox = QVBoxLayout(layer_box)
        vbox.addWidget(self.layer_list)
        btn_add = QPushButton("Add Layer")
        btn_remove = QPushButton("Remove Layer")
        btn_add.clicked.connect(self.add_layer_dialog)
        btn_remove.clicked.connect(self.remove_layer)
        vbox.addWidget(btn_add)
        vbox.addWidget(btn_remove)
        layout.addWidget(layer_box)
        btn_save = QPushButton("Save Model (.json)")
        btn_load = QPushButton("Load Model (.json)")
        btn_save.clicked.connect(self.save_model_json)
        btn_load.clicked.connect(self.load_model_json)
        layout.addWidget(btn_save)
        layout.addWidget(btn_load)
        self.tabs.addTab(tab, "Model Design")
    def add_layer_dialog(self):
        d = QDialog(self)
        d.setWindowTitle("Add Layer")
        v = QVBoxLayout(d)
        typebox = QComboBox()
        typebox.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout", "LSTM", "GRU"])
        v.addWidget(QLabel("Layer Type:"))
        v.addWidget(typebox)
        param_boxes = {}
        def update_params():
            for w in list(param_boxes.values()):
                v.removeWidget(w)
                w.hide()
            param_boxes.clear()
            t = typebox.currentText()
            if t == "Dense":
                s = QSpinBox(); s.setValue(128)
                a = QComboBox(); a.addItems(["relu", "sigmoid", "tanh"])
                v.addWidget(QLabel("Units:")); v.addWidget(s)
                v.addWidget(QLabel("Activation:")); v.addWidget(a)
                param_boxes['units'] = s; param_boxes['activation'] = a
            elif t == "Conv2D":
                f = QSpinBox(); f.setValue(32)
                k = QSpinBox(); k.setValue(3)
                a = QComboBox(); a.addItems(["relu", "sigmoid", "tanh"])
                v.addWidget(QLabel("Filters:")); v.addWidget(f)
                v.addWidget(QLabel("Kernel Size:")); v.addWidget(k)
                v.addWidget(QLabel("Activation:")); v.addWidget(a)
                param_boxes['filters'] = f; param_boxes['kernel_size'] = k; param_boxes['activation'] = a
            elif t == "MaxPooling2D":
                k = QSpinBox(); k.setValue(2)
                v.addWidget(QLabel("Pool Size:")); v.addWidget(k)
                param_boxes['pool_size'] = k
            elif t == "Dropout":
                r = QDoubleSpinBox(); r.setValue(0.5); r.setDecimals(2); r.setRange(0.0, 1.0)
                v.addWidget(QLabel("Dropout Rate:")); v.addWidget(r)
                param_boxes['rate'] = r
            elif t == "Flatten":
                pass
            elif t == "LSTM" or t == "GRU":
                units = QSpinBox(); units.setValue(64)
                ret_seq = QCheckBox("Return Sequences")
                v.addWidget(QLabel("Units:")); v.addWidget(units)
                v.addWidget(ret_seq)
                param_boxes['units'] = units; param_boxes['return_sequences'] = ret_seq
        typebox.currentIndexChanged.connect(update_params)
        update_params()
        btnok = QPushButton("Add")
        btnok.clicked.connect(lambda: d.accept())
        v.addWidget(btnok)
        if d.exec() == QDialog.DialogCode.Accepted:
            t = typebox.currentText()
            params = {}
            for key, widget in param_boxes.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    params[key] = widget.value()
                elif isinstance(widget, QComboBox):
                    params[key] = widget.currentText()
                elif isinstance(widget, QCheckBox):
                    params[key] = widget.isChecked()
            self.layer_items.append(LayerItem(t, params))
            self.layer_list.addItem(str(self.layer_items[-1]))
    def remove_layer(self):
        idx = self.layer_list.currentRow()
        if idx >= 0:
            self.layer_list.takeItem(idx)
            self.layer_items.pop(idx)
    def save_model_json(self):
        fname, _ = QFileDialog.getSaveFileName(self, "Save Model", "", "JSON (*.json)")
        if fname:
            import json
            arr = [{"type": l.layer_type, "params": l.params} for l in self.layer_items]
            with open(fname, "w") as f:
                json.dump(arr, f)
    def load_model_json(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Load Model", "", "JSON (*.json)")
        if fname:
            import json
            with open(fname) as f:
                arr = json.load(f)
            self.layer_items = [LayerItem(l['type'], l['params']) for l in arr]
            self.layer_list.clear()
            for l in self.layer_items:
                self.layer_list.addItem(str(l))
    # ------ Train Tab ------
    def init_train_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        h = QHBoxLayout()
        h.addWidget(QLabel("Optimizer:"))
        self.optbox = QComboBox()
        self.optbox.addItems(["adam", "sgd", "rmsprop"])
        h.addWidget(self.optbox)
        h.addWidget(QLabel("LR:"))
        self.lrbox = QDoubleSpinBox()
        self.lrbox.setDecimals(4); self.lrbox.setValue(0.001); self.lrbox.setSingleStep(0.001)
        h.addWidget(self.lrbox)
        h.addWidget(QLabel("Batch Size:"))
        self.bsbox = QSpinBox()
        self.bsbox.setValue(128)
        h.addWidget(self.bsbox)
        h.addWidget(QLabel("Epochs:"))
        self.epochbox = QSpinBox()
        self.epochbox.setValue(7)
        h.addWidget(self.epochbox)
        v.addLayout(h)
        h2 = QHBoxLayout()
        h2.addWidget(QLabel("LR Scheduler:"))
        self.schbox = QComboBox()
        self.schbox.addItems(["None", "StepDecay", "Exponential"])
        h2.addWidget(self.schbox)
        h2.addWidget(QLabel("Dropout:"))
        self.dropbox = QDoubleSpinBox(); self.dropbox.setDecimals(2); self.dropbox.setValue(0.0)
        h2.addWidget(self.dropbox)
        h2.addWidget(QLabel("L2:"))
        self.l2box = QDoubleSpinBox(); self.l2box.setDecimals(4); self.l2box.setValue(0.0)
        h2.addWidget(self.l2box)
        self.earlystop = QCheckBox("EarlyStopping")
        h2.addWidget(self.earlystop)
        v.addLayout(h2)
        trainbtn = QPushButton("Train")
        trainbtn.clicked.connect(self.train_model)
        v.addWidget(trainbtn)
        v.addWidget(self.train_log)
        self.tabs.addTab(tab, "Train/Evaluate")
    def build_model(self):
        model = models.Sequential()
        first = True
        for l in self.layer_items:
            t, p = l.layer_type, l.params
            if t == "Dense":
                if first:
                    model.add(layers.Flatten(input_shape=(28,28,1)))
                    first = False
                reg = regularizers.l2(self.l2box.value()) if self.l2box.value() > 0 else None
                model.add(layers.Dense(p['units'], activation=p['activation'], kernel_regularizer=reg))
            elif t == "Conv2D":
                if first:
                    model.add(layers.Conv2D(p['filters'], (p['kernel_size'], p['kernel_size']), activation=p['activation'], input_shape=(28,28,1)))
                    first = False
                else:
                    model.add(layers.Conv2D(p['filters'], (p['kernel_size'], p['kernel_size']), activation=p['activation']))
            elif t == "MaxPooling2D":
                model.add(layers.MaxPooling2D((p['pool_size'], p['pool_size'])))
            elif t == "Dropout":
                rate = p.get('rate', self.dropbox.value())
                model.add(layers.Dropout(rate))
            elif t == "Flatten":
                model.add(layers.Flatten())
            elif t == "LSTM":
                if first:
                    model.add(layers.LSTM(p['units'], return_sequences=p['return_sequences'], input_shape=(28,28)))
                    first = False
                else:
                    model.add(layers.LSTM(p['units'], return_sequences=p['return_sequences']))
            elif t == "GRU":
                if first:
                    model.add(layers.GRU(p['units'], return_sequences=p['return_sequences'], input_shape=(28,28)))
                    first = False
                else:
                    model.add(layers.GRU(p['units'], return_sequences=p['return_sequences']))
        model.add(layers.Dense(10, activation="softmax"))
        return model
    def train_model(self):
        self.train_log.clear()
        model = self.build_model()
        opt = self.optbox.currentText()
        lr = self.lrbox.value()
        if opt == "adam":
            optimizer = optimizers.Adam(learning_rate=lr)
        elif opt == "sgd":
            optimizer = optimizers.SGD(learning_rate=lr)
        elif opt == "rmsprop":
            optimizer = optimizers.RMSprop(learning_rate=lr)
        sch = self.schbox.currentText()
        if sch == "StepDecay":
            lr_schedule = optimizers.schedules.ExponentialDecay(initial_learning_rate=lr, decay_steps=1000, decay_rate=0.5)
            optimizer.learning_rate = lr_schedule
        elif sch == "Exponential":
            lr_schedule = optimizers.schedules.ExponentialDecay(initial_learning_rate=lr, decay_steps=1000, decay_rate=0.9)
            optimizer.learning_rate = lr_schedule
        model.compile(optimizer=optimizer, loss="sparse_categorical_crossentropy", metrics=["accuracy"])
        cbs = []
        if self.earlystop.isChecked():
            cbs.append(callbacks.EarlyStopping(patience=3, monitor="val_loss", restore_best_weights=True))
        self.train_thread = TrainThread(
            model,
            self.x_train, self.y_train,
            self.x_test[:2000], self.y_test[:2000],
            self.bsbox.value(), self.epochbox.value(), cbs
        )
        self.train_thread.log_signal.connect(self.train_log.append)
        self.train_thread.finished_signal.connect(self.training_done)
        self.train_thread.start()
        self.current_model = model
    def training_done(self, hist):
        self.training_history = hist
        self.train_log.append("Training Done.")
    # ------ Results Tab ------
    def init_result_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        btn_curve = QPushButton("Plot Training Curves")
        btn_curve.clicked.connect(self.plot_curves)
        btn_metrics = QPushButton("Show Test Metrics")
        btn_metrics.clicked.connect(self.show_metrics)
        btn_grad = QPushButton("Plot Gradient Histogram")
        btn_grad.clicked.connect(self.plot_grad_hist)
        v.addWidget(btn_curve)
        v.addWidget(btn_metrics)
        v.addWidget(btn_grad)
        self.tabs.addTab(tab, "Results")
    def plot_curves(self):
        if self.training_history is None: return
        plt.figure(figsize=(10,4))
        plt.subplot(1,2,1)
        plt.plot(self.training_history["loss"], label="train loss")
        if "val_loss" in self.training_history:
            plt.plot(self.training_history["val_loss"], label="val loss")
        plt.legend(); plt.title("Loss")
        plt.subplot(1,2,2)
        if "accuracy" in self.training_history:
            plt.plot(self.training_history["accuracy"], label="train acc")
            if "val_accuracy" in self.training_history:
                plt.plot(self.training_history["val_accuracy"], label="val acc")
            plt.legend(); plt.title("Accuracy")
        plt.tight_layout()
        plt.show()
    def show_metrics(self):
        if self.current_model is None: return
        res = self.current_model.evaluate(self.x_test, self.y_test, verbose=0)
        msg = f"Test Loss: {res[0]:.4f}\nTest Accuracy: {res[1]:.4f}"
        QMessageBox.information(self, "Test Metrics", msg)
    def plot_grad_hist(self):
        if self.current_model is None: return
        grads = []
        for w in self.current_model.trainable_weights:
            arr = w.numpy().flatten()
            grads.append(arr)
        plt.figure(figsize=(10,5))
        for i, g in enumerate(grads):
            plt.hist(g, bins=40, alpha=0.5, label=f"Layer {i}")
        plt.legend(); plt.title("Weight/Gradient Histogram")
        plt.show()
    # ------ GAN Tab ------
    def init_gan_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.addWidget(QLabel("GAN Example - Simple Training"))
        btn = QPushButton("Train GAN (on MNIST vectors)")
        log = QTextEdit(); log.setReadOnly(True)
        v.addWidget(btn)
        v.addWidget(log)
        progress = QProgressBar()
        v.addWidget(progress)
        self.tabs.addTab(tab, "GAN")
        def start_gan():
            log.clear()
            progress.setValue(0)
            thread = GANThread(self.x_train, epochs=10)
            thread.log_signal.connect(log.append)
            thread.progress_signal.connect(progress.setValue)
            def show_samples(generator):
                noise = np.random.randn(16, thread.latent_dim)
                samples = generator.predict(noise, verbose=0)
                samples = (samples + 1) / 2
                plt.figure(figsize=(4,4))
                for i, img in enumerate(samples):
                    plt.subplot(4,4,i+1)
                    plt.imshow(img.reshape(28,28), cmap="gray")
                    plt.axis("off")
                plt.suptitle("GAN Üretilen Örnekler")
                plt.show()
            thread.finished_signal.connect(show_samples)
            thread.start()
        btn.clicked.connect(start_gan)
    # ------ Transfer Learning Tab ------
    def init_transfer_tab(self):
        tab = QWidget()
        v = QVBoxLayout(tab)
        v.addWidget(QLabel("Transfer Learning (VGG16/ResNet)"))
        btn = QPushButton("Load VGG16 & Fine-tune")
        v.addWidget(btn)
        self.tabs.addTab(tab, "Transfer Learning")
        def train_transfer():
            xtr = np.repeat(self.x_train, 3, axis=-1)
            xts = np.repeat(self.x_test, 3, axis=-1)
            base = tf.keras.applications.VGG16(include_top=False, input_shape=(28,28,3), weights="imagenet")
            base.trainable = False
            model = models.Sequential([
                base,
                layers.Flatten(),
                layers.Dense(128, activation="relu"),
                layers.Dropout(0.5),
                layers.Dense(10, activation="softmax"),
            ])
            model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
            hist = model.fit(xtr, self.y_train, epochs=3, batch_size=128, validation_split=0.2, verbose=1)
            res = model.evaluate(xts, self.y_test, verbose=0)
            QMessageBox.information(self, "VGG16 Transfer Test", f"Test Accuracy: {res[1]:.4f}")
            plt.plot(hist.history["accuracy"], label="train acc")
            plt.plot(hist.history["val_accuracy"], label="val acc")
            plt.legend(); plt.title("Transfer Learning Eğrisi"); plt.show()
        btn.clicked.connect(train_transfer)

def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    app.exec()

if __name__ == "__main__":
    main()